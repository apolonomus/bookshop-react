import Navbar from './Navbar/Navbar';
import Banner from './Banner/Banner';
import Products from './Products/Products';
import CategoryMenu from './CategoryMenu/CategoryMenu';


const Home =  () => {
    return (
        <>
            <Navbar />
            <Banner />
            <div className='product-category'>
                <CategoryMenu />
            </div>
            <div className='product-card-container'>
                <Products />
            </div>
        </>
    );
};

export default Home;
